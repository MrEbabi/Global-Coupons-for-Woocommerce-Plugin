=== Plugin Name ===
Plugin Name: Global Coupons for Woocommerce
Description: Generate availability-restricted WooCommerce coupons that can be seen and used by customer on My Account page.
Version: 1.0.0
Author: Mr.Ebabi
Author URI: http://mrebabi.com
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: global-coupons
=== Plugin Details ===
Global Coupons are the customizated WooCommerce coupons that has several restriction options and regarding to them available for the customers. 
Customers can inspect the Active or Deactive Global Coupons on the My Account - Coupons part. 
If a coupon is active for customer, she/he can directly apply the coupon unless their cart is empty.
The coupon restrictions are: First Order, Number of Orders, Amount of Orders, Special For You, Number of Reviews and Activate Date Interval.
Use of Global Coupons at the Admin Panel is explained with examples and regular inputs for every part in admin submenus of Plugin.
